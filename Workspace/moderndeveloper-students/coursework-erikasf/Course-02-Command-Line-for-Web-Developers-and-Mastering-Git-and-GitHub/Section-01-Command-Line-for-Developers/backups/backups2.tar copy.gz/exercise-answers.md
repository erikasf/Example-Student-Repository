# Exercise Answers
##Beginner
1. Write the command that will allow you to navigate to two directories above your current directory. Study these examples: 
  ```
  Ryan@RyansLaptop ~/Coursework/Fall 2015/BIOL13/
  to
  Ryan@RyansLaptop ~/Coursework/
  cd ../../ or to move down the file tree in the reverse direction is 
  cd Fall2015/BIOL13/

  Steve@FamilyComputer ~/My Documents/Book Library/Francine Jay/The Joy of Less/
  to
  Steve@FamilyComputer ~/My Documents/Book Library/
  cd ../../ 

  ```
2. Write the command and flag that will list the files and directories inside of your current directory.
Current directory or path:
  ```
 Ryan@RyansLaptop ~/Coursework/Fall 2015/ 
 command.       flag	
 ***ls*** *** -a***(shows hidden files)
 			
  ```
3.  
  ```
 | Command | flag |
| ------ | ----------- |
|***ls*** | 
|       ||


  ```
4.
```
| Command | flag |
| ------ | ----------- |
|***ls*** | ***-l***
|       |expanded view|

5.
```
mkdir clean_code_examples
```
6.
```
touch anythingIlike.txt
```
7.
```
cat socks_to_buy.text
```
8.
```
pwd
```
9.
```
there are actually a few ways to discover that 
there is:
echo "$(whoami)"
or 
echo "$(id -u -n)"

10.
```
ls ../../
```

11.
```
touch list_of_best_cat_pictures.html
```
12.
```
cd: c/Users/Default/User/My_Documents
 ```
 13
 ```
 ping 8.8.8.8
 ```
 14
 ```
 command prompt: ~

 ```
 15
 ```

 NAME1 = ' RYAN
 '
 NAME2 = "SHARON"
  echo = "WELCOME, $(NAME1)"
 echo = "WELCOME, $(NAME2)"
 ```
16
```
cat tylers_favorite_songs.txt; sarahs_favorite_songs.txt

```
17
```
  man echo > ./echo_options.txt

  ```
  18
  ```
ping -c 2 127.0.0.1
  ```
  19
  ```
  ls *.md

  ```
  20
  ```
 remove(./yesterdays_todo_list.md)


##Intermediate
du -h -s
 touch myname.md   
    echo "Erika Harvey" >> myname.md
    touch myfavoritefoods.md
    echo "tiriamisu,beer,steak" >> myfavoritefoods.md
    touch dreamproject.md
    echo "patient advocate portal" >> dreamproject.md
    touch music.md
    echo "Depeche Mode" >> music.md
    touch colors.md
    echo "indigo" >> colors.md








